package model;

public class Venda {

}
